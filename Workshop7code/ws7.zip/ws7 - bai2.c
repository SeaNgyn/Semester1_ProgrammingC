#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

char code[50][8];
char name[50][20];
double salary[50];
double allowance[50];

int i=0;

void addnew(){
	getchar();
	system("cls");
	printf("Nhap ma: ");
	scanf("%s",code[i]);
	getchar();
	printf("\nNhap ten: ");
	gets(name[i]);
	printf("\nNhap luong: ");
	scanf("%lf",&salary[i]);
	printf("\nNhap phu cap: ");
	scanf("%lf",&allowance[i]);
	i++;
	printf("\nAdded new\n\n");
}

void tim(){
	getchar();
	system("cls");
	char ten[20];
	printf("Nhap ten nhan vien muon tim: ");
	gets(ten);
	int index=-1;
	for(int j=0; j<=i; j++){
		if(strcmp(name[j],ten)==0){
			index=j;
			break;
		}
	}
	if(index==-1) printf("Khong co du lieu\n\n");
	else{
		printf("\nMa: %s\nTen: %s\nLuong: %lf\nPhu cap: %lf\n",code[index], name[index], salary[index], allowance[index]);
	}
	printf("\n\n");
}

void xoa(){
	getchar();
	system("cls");
	char ma[8];
	printf("Nhap ma nhan vien muon xoa: ");
	gets(ma);
	int index=-1;
	for(int j=0; j<=i; j++){
		if(strcmp(code[j],ma)==0){
			index=j;
			break;
		}
	}
	if(index==-1) printf("Khong co du lieu can xoa\n\n");
	else{
		for(int j=index; j<i; j++){
			strcpy(code[j],code[j+1]);
			strcpy(name[j],name[j+1]);
			salary[j]=salary[j+1];
			allowance[j]=allowance[j+1];
		}
		--i;
		printf("Da xoa nhan vien khoi danh sach\n\n");
	}
}

void printlist(){
	system("cls");
	for(int j=0; j<i; j++){
		for(int z=j+1; z<=i-j; z++){
			if(salary[j]+allowance[j]<salary[z]+allowance[z]){
				char ma[8], ten[20];
				double t, t2;
				strcpy(ma,code[j]);
				strcpy(ten,name[j]);
				strcpy(code[j],code[z]);
				strcpy(name[j], name[z]);
				strcpy(code[z],ma);
				strcpy(name[z],ten);
				t=salary[j];
				t2=allowance[j];
				salary[j]=salary[z];
				allowance[j]=allowance[z];
				salary[z]=t;
				allowance[z]=t2;
			}
		}
	}
	if(i>0){
		printf("The list based on salary + allowance\n");
		for(int j=0; j<i; j++){
			printf("Thu tu: %d\nMa: %s\nTen: %s\nLuong: %lf\nPhu cap: %lf\n\n",j+1,code[j],name[j],salary[j],allowance[j]);
		}
		printf("\n\n");
	}
	else{
		printf("Chua co nhan vien nao trong danh sach\n\n");
	}
}

int main(){
	int n;
	do{
		printf("1- Add a new employee\n");
		printf("2- Find data about employee by name\n");
		printf("3- Remove an employee based by code\n");
		printf("4- Print the list in descending order based on salary and allowance\n");
		printf("Others- Quit\n");
		printf("Enter your choice: ");
		scanf("%d",&n);
		switch(n){
			case 1:
				addnew();
				break;
			case 2:
				tim();
				break;
			case 3:
				xoa();
				break;
			case 4:
				printlist();
				break;
		}
	}while(n>=1&&n<=4);
}
