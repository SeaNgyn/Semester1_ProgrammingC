#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char name[50][20], make[50][20]; 
int vol[50], price[50], dur[50];
int i=0;

void Add(){
	getchar();
	system("cls");
	printf("Enter the name of new drink: ");
	gets(name[i]);
	printf("Enter the origin: ");
	gets(make[i]);
	printf("Enter the volume, price, duration: ");
	scanf("%d%d%d",&vol[i],&price[i],&dur[i]);
	i++;
	printf("Added new\n\n");
}

void Belong(){
	getchar();
	system("cls");
	char s[20];
	printf("Enter the origin of items you want: ");
	gets(s);
	int j;
	printf("Items which belong to %s:\n", s);
	int cnt=0;
	for(j=0; j<i; j++){
		if(strcmp(make[j],s)==0){
			printf("%d. %s\n", ++cnt, name[j]);
		}
	}
	printf("\n");
}

void Between(){
	system("cls");
	int v1, v2;
	printf("Enter min and max value of volume range: ");
	scanf("%d%d",&v1,&v2);
	int j;
	printf("Items whose volume in range:\n");
	int cnt=0;
	for(j=0; j<i; j++){
		if(vol[j]>=v1&&vol[j]<=v2){
			printf("%d. %s with volumes: %d\n", ++cnt, name[j], vol[j]);
		}
	}
	printf("\n");
}

void swapInt(int *a, int *b){
	int res = *a;
	*a = *b;
	*b = res;
}

void AscendingOrder(){
	system("cls");
	int j,z;
	for(j=0; j<i-1; j++){
		for(z=i-1; z>j; z--){
			if(vol[j]>vol[z]){
				swapInt(&vol[j],&vol[z]);
				swapInt(&price[j],&price[z]);
				swapInt(&dur[j],&dur[z]);
				char t[20];
				strcpy(t, name[j]);
				strcpy(name[j], name[z]);
				strcpy(name[z], t);
				strcpy(t, make[j]);
				strcpy(make[j], make[z]);
				strcpy(make[z], t);
			}
			else if(vol[j]==vol[z]){
				if(price[j]>price[z]){
					swapInt(&vol[j],&vol[z]);
					swapInt(&price[j],&price[z]);
					swapInt(&dur[j],&dur[z]);
					char t[20];
					strcpy(t, name[j]);
					strcpy(name[j], name[z]);
					strcpy(name[z], t);
					strcpy(t, make[j]);
					strcpy(make[j], make[z]);
					strcpy(make[z], t);
				}
			}
		}
	}
	int cnt=0;
	printf("List in ascending order based on volumes then prices:\n");
	for(j=0; j<i; j++){
		printf("%d. %s\nVolume: %d\nPrice: %d\n\n", ++cnt, name[j], vol[j], price[j]);
	}
}

main(){
	int n;
	do{
		printf("1- Adding new soft drink\n");
		printf("2- Printing out items which belong to a known make\n"); // nguon goc xuat xu
		printf("3- Printing out items whose volumes are between v1 and v2\n");
		printf("4- Printing the list in ascending order based on volumes then prices\n");
		printf("Orthers- Quit\n");
		printf("Enter your choice: ");
		scanf("%d",&n);
		switch(n){
			case 1:
				Add();
				break;
			case 2:
				Belong();
				break;
			case 3:
				Between();
				break;
			case 4:
				AscendingOrder();
				break;
		}
	} while(n>=1&&n<=4);
} 
