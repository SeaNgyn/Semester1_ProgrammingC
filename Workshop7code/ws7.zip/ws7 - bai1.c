#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>

char name[100][20];
int i=0;

void Add(){
	getchar();
	system("cls");
	printf("Enter the name: ");
	gets(name[i]);
	i++;
	printf("Added new student\n\n");
}

void Remove(){
	getchar();
	system("cls");
	printf("Enter the name: ");
	char t[20];
	gets(t);
	int j, index=-1;
	for(j=0; j<i; j++){
		if(strcmp(name[j],t)==0){
			index=j;
			break;
		}
	}
	if(index==-1){
		printf("No data\n\n");
	}
	else{
		for(j=index; j<i-1; j++){
			strcpy(name[j],name[j+1]);
		}
		i--;
		printf("Removed student: %s\n\n", t);
	}
}

void Search(){
	getchar();
	system("cls");
	printf("Enter the name: ");
	char t[20];
	gets(t);
	int j, index=-1;
	for(j=0; j<i; j++){
		if(strcmp(name[j],t)==0){
			index=j;
			break;
		}
	}
	if(index==-1){
		printf("No data\n\n");
	}
	else{
		printf("Found student: %s at %dth position\n\n",t,index+1);
	}
}

void PrintList(){
	system("cls");
	int j, z;
	for(j=0; j<i-1; j++){
		for(z=i-1; z>j; z--){
			if(strcmp(name[j],name[z])==1){
				char res[20];
				strcpy(res,name[j]);
				strcpy(name[j],name[z]);
				strcpy(name[z],res);
			}
		}
	}
	printf("Student list in ascending order:\n");
	for(j=0; j<i; j++){
		printf("%d. %s\n",j+1, name[j]);
	}
	printf("\n");
}

int main(){
	int n;
	do{
		printf("1- Add a student\n");
		printf("2- Remove a student\n");
		printf("3- Search a student\n");
		printf("4- Print the list in ascending order\n");
		printf("5- Quit\n");
		printf("Enter your choice: ");
		scanf("%d",&n);
		switch(n){
			case 1:
				Add();
				break;
			case 2:
				Remove();
				break;
			case 3:
				Search();
				break;
			case 4:
				PrintList();
				break;
		}
	}while(n>=1&&n<5);
}
